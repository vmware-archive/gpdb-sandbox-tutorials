select (madlib.linregr(arrdelayminutes, array[1,distance])).* from faa.otp_c;

