SELECT pg_size_pretty(pg_relation_size('faa.otp_r'));
SELECT pg_size_pretty(pg_total_relation_size('faa.otp_r'));
SELECT pg_size_pretty(pg_relation_size('faa.otp_c'));
SELECT pg_size_pretty(pg_total_relation_size('faa.otp_c'));

