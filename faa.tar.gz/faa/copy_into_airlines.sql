--Greenplum 4 version
--\COPY faa.d_airlines FROM 'L_AIRLINE_ID.csv'  CSV HEADER LOG ERRORS INTO faa.faa_load_errors KEEP SEGMENT REJECT LIMIT 50 ROWS;
--Uncomment above to run in GPDB4

--Greenplum 5 version
\COPY faa.d_airlines FROM 'L_AIRLINE_ID.csv'  CSV HEADER LOG ERRORS SEGMENT REJECT LIMIT 50 ROWS;
