select avg(ArrDelayMinutes),variance(ArrDelayMinutes),stddev(ArrDelayMinutes) from faa.otp_c;
select avg(DepDelayMinutes),variance(DepDelayMinutes),stddev(DepDelayMinutes) from faa.otp_c;


